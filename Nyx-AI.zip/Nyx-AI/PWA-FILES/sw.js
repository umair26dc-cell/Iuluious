/* ================================================================
   NYX AI – Service Worker (sw.js)
   Caches core app assets for offline support
   ================================================================ */

const CACHE_NAME    = 'nyx-ai-v1';
const CACHE_TIMEOUT = 5000; // ms before network fallback

/**
 * Assets to pre-cache on install.
 * These are the minimum files needed to render the app shell offline.
 */
const PRECACHE_ASSETS = [
  '../SRC-FILES/index.html',
  '../SRC-FILES/style.css',
  '../SRC-FILES/script.js',
  '../PWA-FILES/manifest.json',
  '../PWA-FILES/favicon.svg',
];

/* ── Install: pre-cache app shell ─────────────────────────── */
self.addEventListener('install', (event) => {
  console.log('[SW] Installing Nyx AI service worker…');
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(PRECACHE_ASSETS);
    })
  );
  /* Activate immediately without waiting for old tabs to close */
  self.skipWaiting();
});

/* ── Activate: clean up old caches ────────────────────────── */
self.addEventListener('activate', (event) => {
  console.log('[SW] Activating Nyx AI service worker…');
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys
          .filter((key) => key !== CACHE_NAME)
          .map((key) => caches.delete(key))
      );
    })
  );
  /* Take control of all open clients immediately */
  self.clients.claim();
});

/* ── Fetch: network-first with cache fallback ─────────────── */
self.addEventListener('fetch', (event) => {
  /* Only handle GET requests */
  if (event.request.method !== 'GET') return;

  /* Skip cross-origin requests to external APIs (Groq, Firebase, Pollinations) */
  const url = new URL(event.request.url);
  const externalHosts = ['api.groq.com', 'firebaseio.com', 'googleapis.com', 'image.pollinations.ai'];
  if (externalHosts.some((h) => url.hostname.includes(h))) return;

  event.respondWith(
    /* Try network first, fall back to cache */
    fetch(event.request)
      .then((response) => {
        /* Cache a fresh copy for next time */
        if (response && response.status === 200) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
        }
        return response;
      })
      .catch(() => {
        /* Network failed – serve from cache */
        return caches.match(event.request);
      })
  );
});
