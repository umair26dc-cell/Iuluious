/* ================================================================
   NYX AI – script.js
   Full application logic: Auth, Chat, Memory, Projects,
   Image Generation, Model Selector, Sidebar, PWA
   ================================================================ */

'use strict';

/* ================================================================
   1. CONFIGURATION
   ================================================================ */

/**
 * Groq API key – used for all LLM inference
 * NOTE: In production always proxy through a backend, never expose keys
 * in client-side code. This is acceptable for a personal/demo project.
 */
const GROQ_API_KEY      = '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';
const GROQ_API_URL      = 'https://api.groq.com/openai/v1/chat/completions';

const CEREBRAS_API_KEY  = 'csk-555hxp6j42hdvw45mnphh5xy239d2y265kxc628rdxecvdyh';
const CEREBRAS_API_URL  = 'https://api.cerebras.ai/v1/chat/completions';

/**
 * Pollinations image generation — free, no key required.
 * Correct endpoint: https://image.pollinations.ai/prompt/{encoded}
 */
const POLLINATIONS_BASE = 'https://image.pollinations.ai/prompt';

/**
 * EmailJS — used to send OTP emails from the browser.
 * Fill in your own EmailJS public key, service ID, and template ID.
 * Sign up free at https://emailjs.com
 */
/* ================================================================
AUTH — Local ID/Password (No EmailJS, No Firebase)
================================================================ */

/** Hash a string using SHA-256 for basic password storage */
async function hashPassword(password) {
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

/** Get stored user by ID from localStorage */
function getUserById(id) {
    try {
        const users = JSON.parse(localStorage.getItem('nyx_users') || '{}');
        return users[id.toLowerCase()] || null;
    } catch { return null; }
}

/** Save or update user in localStorage */
function saveUser(id, hashedPassword, displayName) {
    try {
        const users = JSON.parse(localStorage.getItem('nyx_users') || '{}');
        users[id.toLowerCase()] = { 
            id: id.toLowerCase(), 
            password: hashedPassword, 
            displayName,
            createdAt: Date.now() 
        };
        localStorage.setItem('nyx_users', JSON.stringify(users));
        return true;
    } catch { return false; }
}

/** Initialize auth on load */
function initAuth() {
    // Check if already logged in
    const session = localStorage.getItem('nyx_session');
    if (session) {
        try {
            const user = JSON.parse(session);
            showApp(user);
            return;
        } catch {}
    }
    showAuthOverlay();
}

/** Show login/signup form */
function showAuthOverlay() {
    document.getElementById('auth-overlay').classList.remove('hidden');
    document.getElementById('app').classList.add('hidden');
    
    // Reset to login view
    document.getElementById('auth-step-login').classList.remove('hidden');
    document.getElementById('auth-step-signup').classList.add('hidden');
    document.getElementById('auth-error').classList.add('hidden');
}

/** Handle login */
async function handleLogin() {
    const idInput = document.getElementById('auth-id-input');
    const passInput = document.getElementById('auth-pass-input');
    const errorEl = document.getElementById('auth-error');
    const btn = document.getElementById('btn-login');
    
    const id = idInput.value.trim();
    const password = passInput.value;
    
    if (!id || !password) {
        showAuthError('Enter both ID and password.');
        return;
    }
    
    btn.disabled = true;
    btn.textContent = 'Signing in…';
    
    const user = getUserById(id);
    const hashedPass = await hashPassword(password);
    
    if (!user || user.password !== hashedPass) {
        showAuthError('Invalid ID or password.');
        btn.disabled = false;
        btn.textContent = 'Sign In';
        return;
    }
    
    // Create session
    const sessionUser = {
        uid: user.id,
        displayName: user.displayName,
        email: `${user.id}@nyx.local`
    };
    localStorage.setItem('nyx_session', JSON.stringify(sessionUser));
    showApp(sessionUser);
}

/** Handle signup */
async function handleSignup() {
    const idInput = document.getElementById('auth-signup-id');
    const passInput = document.getElementById('auth-signup-pass');
    const confirmInput = document.getElementById('auth-signup-confirm');
    const nameInput = document.getElementById('auth-signup-name');
    const errorEl = document.getElementById('auth-signup-error');
    const btn = document.getElementById('btn-signup');
    
    const id = idInput.value.trim();
    const password = passInput.value;
    const confirm = confirmInput.value;
    const displayName = nameInput.value.trim() || id;
    
    if (!id || !password || !confirm) {
        showSignupError('All fields are required.');
        return;
    }
    
    if (password.length < 4) {
        showSignupError('Password must be at least 4 characters.');
        return;
    }
    
    if (password !== confirm) {
        showSignupError('Passwords do not match.');
        return;
    }
    
    if (!/^[a-zA-Z0-9_-]+$/.test(id)) {
        showSignupError('ID can only contain letters, numbers, _ and -');
        return;
    }
    
    btn.disabled = true;
    btn.textContent = 'Creating account…';
    
    // Check if ID exists
    if (getUserById(id)) {
        showSignupError('This ID is already taken.');
        btn.disabled = false;
        btn.textContent = 'Create Account';
        return;
    }
    
    const hashedPass = await hashPassword(password);
    saveUser(id, hashedPass, displayName);
    
    // Auto-login after signup
    const sessionUser = {
        uid: id.toLowerCase(),
        displayName,
        email: `${id.toLowerCase()}@nyx.local`
    };
    localStorage.setItem('nyx_session', JSON.stringify(sessionUser));
    showApp(sessionUser);
}

/** Switch between login and signup views */
function toggleAuthMode(mode) {
    if (mode === 'signup') {
        document.getElementById('auth-step-login').classList.add('hidden');
        document.getElementById('auth-step-signup').classList.remove('hidden');
    } else {
        document.getElementById('auth-step-signup').classList.add('hidden');
        document.getElementById('auth-step-login').classList.remove('hidden');
    }
    document.getElementById('auth-error').classList.add('hidden');
    document.getElementById('auth-signup-error').classList.add('hidden');
}

function showAuthError(msg) {
    const el = document.getElementById('auth-error');
    el.textContent = msg;
    el.classList.remove('hidden');
}

function showSignupError(msg) {
    const el = document.getElementById('auth-signup-error');
    el.textContent = msg;
    el.classList.remove('hidden');
}

/** Sign out */
function signOut() {
    localStorage.removeItem('nyx_session');
    showAuthOverlay();
}

/** Show the auth overlay */
function showAuthOverlay() {
  document.getElementById('auth-overlay').classList.remove('hidden');
  document.getElementById('app').classList.add('hidden');
  /* Reset to step 1 */
  document.getElementById('auth-step-email').classList.remove('hidden');
  document.getElementById('auth-step-otp').classList.add('hidden');
}

/** Generate a random 6-digit OTP code */
function generateOTP() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

/**
 * Step 1 — send OTP to the entered email.
 * Uses EmailJS to send the code from the browser with no backend.
 */
async function sendOTP() {
  const emailInput = document.getElementById('auth-email-input');
  const errorEl    = document.getElementById('auth-email-error');
  const btn        = document.getElementById('btn-send-code');

  const email = emailInput.value.trim().toLowerCase();

  /* Basic email validation */
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    showAuthError('auth-email-error', 'Please enter a valid email address.');
    return;
  }

  btn.disabled     = true;
  btn.textContent  = 'Sending…';
  errorEl.classList.add('hidden');

  const code = generateOTP();

  /* Store OTP in state — expires in 10 minutes */
  state.otp = {
    code,
    email,
    expiresAt: Date.now() + 10 * 60 * 1000,
  };

  try {
    await emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, {
      to_email:   email,
      otp_code:   code,
      from_name:  'Nyx AI',
      reply_to:   'no-reply@nyx.ai',
    });

    /* Advance to step 2 */
    document.getElementById('auth-step-email').classList.add('hidden');
    document.getElementById('auth-step-otp').classList.remove('hidden');
    document.getElementById('auth-otp-email-label').textContent = email;
    document.getElementById('auth-otp-input').value = '';
    document.getElementById('auth-otp-input').focus();

  } catch (err) {
    console.error('[Nyx] EmailJS send failed:', err);
    /* Fallback: if EmailJS is not configured, auto-fill so dev can test */
    if (EMAILJS_PUBLIC_KEY === 'YOUR_EMAILJS_PUBLIC_KEY') {
      showToast(`[Dev mode] OTP: ${code}`, 'info');
      document.getElementById('auth-step-email').classList.add('hidden');
      document.getElementById('auth-step-otp').classList.remove('hidden');
      document.getElementById('auth-otp-email-label').textContent = email;
      document.getElementById('auth-otp-input').value = '';
      document.getElementById('auth-otp-input').focus();
    } else {
      showAuthError('auth-email-error', 'Could not send code. Check your connection and try again.');
    }
  } finally {
    btn.disabled    = false;
    btn.textContent = 'Send Login Code';
  }
}

/**
 * Step 2 — verify the entered OTP.
 * On success, creates a user object and stores it in localStorage.
 */
function verifyOTP() {
  const input   = document.getElementById('auth-otp-input');
  const entered = input.value.trim();

  if (!entered || entered.length < 6) {
    showAuthError('auth-otp-error', 'Enter the 6-digit code from your email.');
    return;
  }

  /* Check expiry */
  if (Date.now() > state.otp.expiresAt) {
    showAuthError('auth-otp-error', 'Code expired. Please request a new one.');
    return;
  }

  if (entered !== state.otp.code) {
    showAuthError('auth-otp-error', 'Incorrect code. Try again.');
    input.value = '';
    input.focus();
    return;
  }

  /* Valid — create user session */
  const user = {
    email:       state.otp.email,
    displayName: state.otp.email.split('@')[0],
    photoURL:    '',
    uid:         btoa(state.otp.email), /* stable pseudo-uid for localStorage keying */
  };

  localStorage.setItem('nyx_user', JSON.stringify(user));
  state.otp = { code: '', email: '', expiresAt: 0 };

  showApp(user);
}

/** Display an auth error message */
function showAuthError(elId, msg) {
  const el = document.getElementById(elId);
  if (!el) return;
  el.textContent = msg;
  el.classList.remove('hidden');
}

/** Sign out — clear stored user and return to login */
async function signOut() {
  localStorage.removeItem('nyx_user');
  showAuthOverlay();
}

/** Hide auth overlay, populate sidebar, load data */
async function showApp(user) {
  state.user = user;
  document.getElementById('auth-overlay').classList.add('hidden');
  document.getElementById('app').classList.remove('hidden');

  updateUserProfile(user);

  await Promise.all([ loadChats(), loadMemories(), loadProjects() ]);

  /* Restore saved images */
  const savedImgs = JSON.parse(localStorage.getItem('nyx_recent_images') || '[]');
  state.recentImages = savedImgs;
  renderRecentImages();

  openNewChat();
}

/** Update the sidebar user profile area */
function updateUserProfile(user) {
  const avatar = document.getElementById('user-avatar');
  const name   = document.getElementById('user-name');
  const email  = document.getElementById('user-email');
  avatar.src        = user.photoURL || generateInitialsAvatar(user.displayName || 'N');
  name.textContent  = user.displayName || 'User';
  email.textContent = user.email || '';
}

/** Generate a simple initials SVG avatar */
function generateInitialsAvatar(name) {
  const initials = name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32">
    <circle cx="16" cy="16" r="16" fill="#ff6b35"/>
    <text x="16" y="21" font-family="Inter,sans-serif" font-size="12"
      font-weight="700" fill="white" text-anchor="middle">${initials}</text>
  </svg>`;
  return `data:image/svg+xml;base64,${btoa(svg)}`;
}

/* ================================================================
   5. DATA LAYER – Firestore + localStorage fallback
   ================================================================ */

/* ── Helpers ──────────────────────────────────────────────── */

function userId() {
  return state.user?.uid || 'guest';
}

/** Read a Firestore collection into an array */
async function fsRead(path) {
  if (!state.useFirebase) return lsRead(path);
  try {
    const snap = await db.collection(`users/${userId()}/${path}`).orderBy('createdAt', 'desc').get();
    return snap.docs.map(d => ({ id: d.id, ...d.data() }));
  } catch { return []; }
}

/** Write a doc to Firestore (returns the doc id) */
async function fsWrite(path, data) {
  if (!state.useFirebase) return lsWrite(path, data);
  try {
    const ref = await db.collection(`users/${userId()}/${path}`).add({
      ...data,
      createdAt: firebase.firestore.FieldValue.serverTimestamp(),
    });
    return ref.id;
  } catch (err) {
    console.error('[Nyx] fsWrite error:', err);
    return null;
  }
}

/** Update a doc in Firestore */
async function fsUpdate(path, id, data) {
  if (!state.useFirebase) return lsUpdate(path, id, data);
  try {
    await db.doc(`users/${userId()}/${path}/${id}`).update(data);
  } catch (err) {
    console.error('[Nyx] fsUpdate error:', err);
  }
}

/** Delete a doc from Firestore */
async function fsDelete(path, id) {
  if (!state.useFirebase) return lsDelete(path, id);
  try {
    await db.doc(`users/${userId()}/${path}/${id}`).delete();
  } catch (err) {
    console.error('[Nyx] fsDelete error:', err);
  }
}

/* ── localStorage fallback ─────────────────────────────────── */

function lsKey(path) { return `nyx_${userId()}_${path}`; }

function lsRead(path) {
  try { return JSON.parse(localStorage.getItem(lsKey(path)) || '[]'); }
  catch { return []; }
}

function lsWrite(path, data) {
  const items = lsRead(path);
  const id = `ls_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  items.unshift({ id, ...data, createdAt: new Date().toISOString() });
  localStorage.setItem(lsKey(path), JSON.stringify(items));
  return id;
}

function lsUpdate(path, id, data) {
  const items = lsRead(path);
  const idx = items.findIndex(i => i.id === id);
  if (idx !== -1) {
    items[idx] = { ...items[idx], ...data };
    localStorage.setItem(lsKey(path), JSON.stringify(items));
  }
}

function lsDelete(path, id) {
  const items = lsRead(path).filter(i => i.id !== id);
  localStorage.setItem(lsKey(path), JSON.stringify(items));
}

/* ── Chat persistence ──────────────────────────────────────── */

async function loadChats() {
  state.chats = await fsRead('chats');
  renderChatList();
}

async function saveNewChat(title, messages) {
  if (state.isPrivateChat) return null; // Private chats are not persisted

  const id = await fsWrite('chats', { title, messages: JSON.stringify(messages) });
  state.chats.unshift({ id, title, messages: JSON.stringify(messages) });
  renderChatList();
  return id;
}

async function updateChatMessages(chatId, messages) {
  if (!chatId || state.isPrivateChat) return;
  await fsUpdate('chats', chatId, { messages: JSON.stringify(messages) });
}

async function deleteChat(chatId) {
  await fsDelete('chats', chatId);
  state.chats = state.chats.filter(c => c.id !== chatId);
  renderChatList();
  if (state.activeChatId === chatId) openNewChat();
}

/* ── Memory persistence ────────────────────────────────────── */

async function loadMemories() {
  state.memories = await fsRead('memories');
}

async function addMemory(text) {
  const id = await fsWrite('memories', { text });
  state.memories.unshift({ id, text });
}

async function deleteMemory(id) {
  await fsDelete('memories', id);
  state.memories = state.memories.filter(m => m.id !== id);
}

async function clearAllMemories() {
  for (const m of state.memories) {
    await fsDelete('memories', m.id);
  }
  state.memories = [];
}

/* ── Projects persistence ──────────────────────────────────── */

async function loadProjects() {
  state.projects = await fsRead('projects');
  renderProjectList();
}

async function createProject(name, type) {
  const id = await fsWrite('projects', { name, type, notes: '' });
  state.projects.unshift({ id, name, type, notes: '' });
  renderProjectList();
  return id;
}

async function updateProjectNotes(id, notes) {
  await fsUpdate('projects', id, { notes });
  const proj = state.projects.find(p => p.id === id);
  if (proj) proj.notes = notes;
}

async function deleteProject(id) {
  await fsDelete('projects', id);
  state.projects = state.projects.filter(p => p.id !== id);
  renderProjectList();
}

/* ================================================================
   6. CHAT LOGIC
   ================================================================ */

/**
 * Open a brand-new, empty chat (also used as "home" screen).
 * @param {boolean} isPrivate – if true, chat is not saved
 */
function openNewChat(isPrivate = false) {
  state.activeChatId  = null;
  state.messages      = [];
  state.isPrivateChat = isPrivate;
  state.activeProjectId = null;

  /* Show/hide private indicator in topbar */
  document.getElementById('private-indicator')
    .classList.toggle('hidden', !isPrivate);

  /* Show welcome screen, hide messages area */
  showWelcomeScreen();

  /* Clear any active highlights in the sidebar */
  document.querySelectorAll('.sidebar-item.active')
    .forEach(el => el.classList.remove('active'));
}

/**
 * Load an existing chat by id
 */
function openChat(chatId) {
  const chat = state.chats.find(c => c.id === chatId);
  if (!chat) return;

  state.activeChatId  = chatId;
  state.isPrivateChat = false;
  state.activeProjectId = null;
  state.messages = JSON.parse(chat.messages || '[]');

  /* Highlight in sidebar */
  document.querySelectorAll('.sidebar-item').forEach(el => {
    el.classList.toggle('active', el.dataset.chatId === chatId);
  });

  /* Hide project view, show chat view */
  document.getElementById('project-view').classList.add('hidden');
  document.getElementById('main-content').style.display = 'flex';

  /* Render messages */
  hideWelcomeScreen();
  renderAllMessages();
  scrollToBottom();
}

/**
 * Send a user message to Groq and stream the response
 */
async function sendMessage(userText) {
  if (!userText || !userText.trim() || state.isLoading) return;

  /* Check if this is an image generation request */
  if (isImageRequest(userText)) {
    await handleImageGenRequest(userText);
    return;
  }

  /* Build message object */
  const userMsg = { role: 'user', content: userText, ts: Date.now() };
  state.messages.push(userMsg);

  /* Create a new chat record on first message */
  if (!state.activeChatId && !state.isPrivateChat) {
    const title = userText.slice(0, 60) + (userText.length > 60 ? '…' : '');
    state.activeChatId = await saveNewChat(title, state.messages);
  }

  /* Show messages area if it was hidden */
  hideWelcomeScreen();
  appendMessage(userMsg);
  scrollToBottom();

  /* Show loading state */
  state.isLoading = true;
  setInputDisabled(true);
  showThinkingIndicator();

  try {
    /* Build the prompt context (system + memories + conversation) */
    const apiMessages = buildApiMessages();

    /* Stream the response from Groq */
    const assistantText = await streamGroqResponse(apiMessages);

    /* Save assistant message */
    const assistantMsg = { role: 'assistant', content: assistantText, ts: Date.now() };
    state.messages.push(assistantMsg);

    /* Persist updated messages */
    await updateChatMessages(state.activeChatId, state.messages);

    /* Auto-extract memories from the conversation */
    autoExtractMemories(userText, assistantText);

  } catch (err) {
    console.error('[Nyx] Groq error:', err);
    appendErrorMessage('Something went wrong: ' + err.message);
  } finally {
    state.isLoading = false;
    setInputDisabled(false);
    hideThinkingIndicator();
    scrollToBottom();
  }
}

/**
 * Build the messages array sent to Groq:
 * system prompt + memory profile + recent conversation history
 */
function buildApiMessages() {
  const msgs = [];

  /* System prompt */
  let system = SYSTEM_PROMPT;

  /* Inject memories into system context */
  if (state.memories.length > 0) {
    const memoryBlock = state.memories
      .slice(0, 10) /* Cap at 10 memories to save tokens */
      .map(m => `- ${m.text}`)
      .join('\n');
    system += `\n\nHere is what you remember about this user:\n${memoryBlock}`;
  }

  msgs.push({ role: 'system', content: system });

  /* Conversation history — keep last 20 messages to stay within free-tier TPM */
  const history = state.messages.slice(-20);
  for (const m of history) {
    msgs.push({ role: m.role, content: m.content });
  }

  return msgs;
}

/**
 * Stream a response from the Groq API.
 * Returns the full assistant text once streaming is complete.
 */
async function streamGroqResponse(messages) {
  const response = await fetch(GROQ_API_URL, {
    method: 'POST',
    headers: {
      'Content-Type':  'application/json',
      'Authorization': `Bearer ${GROQ_API_KEY}`,
    },
    body: JSON.stringify({
      model:       state.selectedModel,
      messages,
      stream:      true,
      temperature: 0.7,
      max_tokens:  4096,   /* keep within free-tier TPM limits */
    }),
  });

  if (!response.ok) {
    const errData = await response.json().catch(() => ({}));
    throw new Error(errData.error?.message || `HTTP ${response.status}`);
  }

  /* Create a placeholder message element for streaming */
  const msgEl = appendStreamingMessage();

  const reader  = response.body.getReader();
  const decoder = new TextDecoder();
  let   fullText = '';
  let   buffer   = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });

    /* SSE chunks: split on newlines, look for "data: {...}" lines */
    const lines = buffer.split('\n');
    buffer = lines.pop(); // Keep incomplete last line in buffer

    for (const line of lines) {
      if (!line.startsWith('data: ')) continue;
      const data = line.slice(6).trim();
      if (data === '[DONE]') break;

      try {
        const parsed = JSON.parse(data);
        const delta  = parsed.choices?.[0]?.delta?.content || '';
        if (delta) {
          fullText += delta;
          updateStreamingMessage(msgEl, fullText);
        }
      } catch {
        /* Ignore malformed chunks */
      }
    }
  }

  /* Finalise the streamed message element */
  finaliseStreamingMessage(msgEl, fullText);

  return fullText;
}

/* ================================================================
   7. MESSAGE RENDERING
   ================================================================ */

/**
 * Show the welcome screen — input bar is embedded inside it.
 * Hide the bottom chat bar and the messages area.
 */
function showWelcomeScreen() {
  document.getElementById('welcome-screen').classList.remove('hidden');
  document.getElementById('messages-area').classList.add('hidden');
  document.getElementById('chat-input-wrapper').classList.add('hidden');
  renderGreetingScreen();
}

/**
 * Hide the welcome screen — reveal messages and the bottom chat bar.
 */
function hideWelcomeScreen() {
  document.getElementById('welcome-screen').classList.add('hidden');
  document.getElementById('messages-area').classList.remove('hidden');
  document.getElementById('chat-input-wrapper').classList.remove('hidden');
}

/**
 * Render ALL messages in state.messages from scratch
 * (used when loading an existing chat)
 */
function renderAllMessages() {
  const area = document.getElementById('messages-area');
  area.innerHTML = '';
  for (const msg of state.messages) {
    const el = createMessageElement(msg);
    area.appendChild(el);
  }
}

/**
 * Append a single new message element (for live messages)
 */
function appendMessage(msg) {
  const area = document.getElementById('messages-area');
  const el   = createMessageElement(msg);
  area.appendChild(el);
}

/**
 * Create a DOM element for a message object
 */
function createMessageElement(msg) {
  const div = document.createElement('div');
  div.className = `message ${msg.role}`;
  div.dataset.ts = msg.ts;

  /* Avatar */
  const avatarEl = document.createElement(msg.role === 'assistant' ? 'div' : 'img');
  avatarEl.className = 'message-avatar';
  if (msg.role === 'assistant') {
    avatarEl.classList.add('nyx-avatar');
    avatarEl.textContent = 'N';
  } else {
    avatarEl.src = state.user?.photoURL || generateInitialsAvatar(state.user?.displayName || 'U');
    avatarEl.alt = 'You';
  }

  /* Body */
  const body   = document.createElement('div');
  body.className = 'message-body';

  /* Bubble */
  const bubble = document.createElement('div');
  bubble.className = 'message-bubble';

  if (msg.role === 'assistant') {
    bubble.innerHTML = renderMarkdown(msg.content);
    highlightCodeBlocks(bubble);
  } else {
    /* User messages — strip out fenced file blocks and show them as chips */
    const { displayText, fileBlocks } = extractFileBlocksFromMessage(msg.content);

    /* Show file attachment chips inside bubble FIRST */
    fileBlocks.forEach(fb => {
      const block = document.createElement('div');
      block.className = 'file-attachment-block';
      const icon = FILE_ICONS[fb.ext] || '📄';
      block.innerHTML = `
        <span class="file-icon">${icon}</span>
        <div class="file-attachment-meta">
          <span class="file-attachment-name">${escapeHtml(fb.name)}</span>
          <span class="file-attachment-size">Attached</span>
        </div>`;
      bubble.appendChild(block);
    });

    /* Then show the actual text (if any) */
    if (displayText) {
      const textNode = document.createElement('span');
      textNode.style.whiteSpace = 'pre-wrap';
      textNode.textContent = displayText;
      bubble.appendChild(textNode);
    }
  }

  /* Timestamp */
  const ts = document.createElement('span');
  ts.className = 'message-ts';
  ts.textContent = formatTimestamp(msg.ts);

  body.appendChild(bubble);
  body.appendChild(ts);

  div.appendChild(avatarEl);
  div.appendChild(body);

  return div;
}

/**
 * Append a streaming placeholder element and return it.
 * The bubble content will be updated live as tokens arrive.
 */
function appendStreamingMessage() {
  const area = document.getElementById('messages-area');

  const div    = document.createElement('div');
  div.className = 'message assistant';

  const avatarEl = document.createElement('div');
  avatarEl.className = 'message-avatar nyx-avatar';
  avatarEl.textContent = 'N';

  const body   = document.createElement('div');
  body.className = 'message-body';

  const bubble = document.createElement('div');
  bubble.className = 'message-bubble streaming';
  bubble.innerHTML = '<span class="cursor">▋</span>';

  body.appendChild(bubble);
  div.appendChild(avatarEl);
  div.appendChild(body);
  area.appendChild(div);

  return div;
}

/**
 * Update the streaming message bubble with partial text
 */
function updateStreamingMessage(el, text) {
  const bubble = el.querySelector('.message-bubble');
  if (!bubble) return;

  /* Process DeepSeek R1 thinking tags */
  const processed = processThinkingTags(text);
  bubble.innerHTML = processed + '<span class="cursor">▋</span>';
  highlightCodeBlocks(bubble);
  scrollToBottom();
}

/**
 * Finalise a streaming message (remove cursor, apply full markdown)
 */
function finaliseStreamingMessage(el, text) {
  const bubble = el.querySelector('.message-bubble');
  if (!bubble) return;

  bubble.classList.remove('streaming');
  bubble.innerHTML = renderMarkdown(text);
  highlightCodeBlocks(bubble);

  /* Add timestamp */
  const ts = document.createElement('span');
  ts.className = 'message-ts';
  ts.textContent = formatTimestamp(Date.now());
  el.querySelector('.message-body').appendChild(ts);
}

/** Append an error message bubble */
function appendErrorMessage(text) {
  const area = document.getElementById('messages-area');
  const div  = document.createElement('div');
  div.className = 'message assistant';
  div.innerHTML = `
    <div class="message-avatar nyx-avatar">N</div>
    <div class="message-body">
      <div class="message-bubble" style="color:var(--danger);border-color:var(--danger)">
        ⚠ ${text}
      </div>
    </div>`;
  area.appendChild(div);
}

/**
 * Strip / collapse model thinking blocks.
 *
 * Handles three formats seen in the wild:
 *  1. <think>…</think>  — DeepSeek R1, Qwen (complete tag)
 *  2. <think>…         — Qwen streaming (tag not yet closed)
 *  3. Raw numbered-list reasoning that Qwen sometimes emits before
 *     the real answer (detected by the heuristic: text before the
 *     first blank line + bold heading is all "thinking prose").
 *
 * Complete <think> blocks are collapsed into a <details> summary.
 * Incomplete open tags (still streaming) are hidden entirely until closed.
 */
function processThinkingTags(text) {
  /* 1 — Replace complete <think>…</think> with a collapsible block */
  let processed = text.replace(
    /<think>([\s\S]*?)<\/think>/g,
    (_, thinking) => {
      const trimmed = thinking.trim();
      if (!trimmed) return '';
      return `<details class="thinking-block">` +
             `<summary>Chain of Thought</summary>` +
             `<pre style="white-space:pre-wrap;font-size:11.5px;color:var(--text-muted);line-height:1.5">${escapeHtml(trimmed)}</pre>` +
             `</details>`;
    }
  );

  /* 2 — Hide an open <think> tag that hasn't been closed yet (streaming) */
  processed = processed.replace(/<think>[\s\S]*$/, '<span style="display:none"></span>');

  return processed;
}

/**
 * Post-process a fully streamed / completed assistant response.
 * Strips any residual <think> content and renders the clean answer.
 */
function cleanCompletedResponse(text) {
  /* Remove everything inside <think>…</think> from the stored text */
  return text.replace(/<think>[\s\S]*?<\/think>/g, '').trim();
}

/**
 * Render markdown to HTML.
 * For completed messages (non-streaming) we strip think tags from the
 * stored text before rendering so they never appear raw.
 */
function renderMarkdown(text) {
  /* Remove complete think blocks — they're shown only in the streaming
     collapsible; stored message text should be clean */
  const clean = cleanCompletedResponse(text);
  const withThinking = processThinkingTags(text); /* keep collapsible for display */

  marked.setOptions({ breaks: true, gfm: true });

  /* If the text had think tags, render with collapsible; otherwise render clean */
  const source = text.includes('<think>') ? withThinking : clean;
  return marked.parse(source);
}

/** Run highlight.js on all code blocks inside an element */
function highlightCodeBlocks(el) {
  el.querySelectorAll('pre code').forEach(block => {
    hljs.highlightElement(block);
  });
}

/** Escape HTML special characters */
function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/**
 * Extract fenced file blocks injected by handleSend from a user message string.
 * Returns the clean display text (without the fenced blocks) and an array of
 * { name, ext } objects for each file block found.
 *
 * Pattern matched:  ```ext filename="name.ext"\n…content…\n```
 */
function extractFileBlocksFromMessage(content) {
  const fileBlocks  = [];
  /* Regex matches the fenced block header we inject in handleSend */
  const blockRegex  = /```\S* filename="([^"]+)"\n[\s\S]*?```/g;

  let displayText = content.replace(blockRegex, (match, filename) => {
    const ext = filename.split('.').pop().toLowerCase();
    fileBlocks.push({ name: filename, ext });
    return ''; /* strip from display text */
  }).trim();

  return { displayText, fileBlocks };
}

/** Format a unix timestamp as a readable time string */
function formatTimestamp(ts) {
  if (!ts) return '';
  return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

/** Scroll the messages area to the bottom */
function scrollToBottom() {
  const area = document.getElementById('messages-area');
  if (area) area.scrollTop = area.scrollHeight;
}

/* ================================================================
   8. GREETING SCREENS (10 variations)
   ================================================================ */

/**
 * 10 greeting screen configurations.
 * Each has a heading and 4 suggestion chips.
 */
const GREETING_SCREENS = [
  {
    heading: 'What do you want to explore today?',
    chips: [
      { icon: '🧠', text: 'Explain a complex concept simply' },
      { icon: '💻', text: 'Help me debug my code' },
      { icon: '✍️', text: 'Write something creative' },
      { icon: '📊', text: 'Analyze data or a problem' },
    ],
  },
  {
    heading: 'What\'s on your mind?',
    chips: [
      { icon: '🔬', text: 'Deep-dive into a scientific topic' },
      { icon: '🗺️', text: 'Plan a project from scratch' },
      { icon: '🧮', text: 'Solve a math or logic puzzle' },
      { icon: '📝', text: 'Summarize a document or article' },
    ],
  },
  {
    heading: 'Ready to think together.',
    chips: [
      { icon: '⚙️', text: 'Architect a software system' },
      { icon: '🌐', text: 'Research a topic in depth' },
      { icon: '🎯', text: 'Brainstorm ideas for a project' },
      { icon: '🔍', text: 'Review my writing or code' },
    ],
  },
  {
    heading: 'Let\'s figure something out.',
    chips: [
      { icon: '📐', text: 'Explain a math problem step by step' },
      { icon: '🤖', text: 'Compare AI tools or models' },
      { icon: '🚀', text: 'Optimize my workflow or code' },
      { icon: '💡', text: 'Give me startup ideas' },
    ],
  },
  {
    heading: 'Ask me anything.',
    chips: [
      { icon: '🏗️', text: 'Design a database schema' },
      { icon: '📖', text: 'Recommend books or resources' },
      { icon: '🧩', text: 'Break down a complex system' },
      { icon: '🎨', text: 'Generate an image from my idea' },
    ],
  },
  {
    heading: 'What problem shall we tackle?',
    chips: [
      { icon: '🔐', text: 'Review my security setup' },
      { icon: '📱', text: 'Help build a mobile app' },
      { icon: '🌍', text: 'Translate and explain text' },
      { icon: '📈', text: 'Analyze business strategy' },
    ],
  },
  {
    heading: 'Think of me as your reasoning engine.',
    chips: [
      { icon: '⚖️', text: 'Weigh pros and cons of a decision' },
      { icon: '🧬', text: 'Explain a biology or chemistry concept' },
      { icon: '🎬', text: 'Write a script or story outline' },
      { icon: '🛠️', text: 'Help me fix a bug in my project' },
    ],
  },
  {
    heading: 'Deep thinking, at your service.',
    chips: [
      { icon: '📡', text: 'Explain how a technology works' },
      { icon: '🧪', text: 'Walk through an experiment design' },
      { icon: '🗣️', text: 'Practice an interview or pitch' },
      { icon: '📋', text: 'Create a detailed action plan' },
    ],
  },
  {
    heading: 'What will we build today?',
    chips: [
      { icon: '🌱', text: 'Start a new coding project' },
      { icon: '💬', text: 'Help me write a message or email' },
      { icon: '🔭', text: 'Explore a philosophical question' },
      { icon: '🧭', text: 'Help me make a difficult decision' },
    ],
  },
  {
    heading: 'I\'m Nyx. Let\'s reason through it.',
    chips: [
      { icon: '🏛️', text: 'Explain a historical event deeply' },
      { icon: '⚡', text: 'Speed up my algorithm or query' },
      { icon: '🎓', text: 'Teach me something new today' },
      { icon: '🌊', text: 'Help me get unstuck on a problem' },
    ],
  },
];

/** Last greeting index (avoid repeating same greeting back-to-back) */
let lastGreetingIndex = -1;

/**
 * Pick a random greeting screen (different from last one) and render it
 */
/**
 * Pick a random greeting heading (different from the last one) and render it.
 * Suggestion chips are removed — welcome screen is a clean, minimal empty state.
 */
function renderGreetingScreen() {
  let idx;
  do {
    idx = Math.floor(Math.random() * GREETING_SCREENS.length);
  } while (idx === lastGreetingIndex);
  lastGreetingIndex = idx;

  const screen   = GREETING_SCREENS[idx];
  const userName = state.user?.displayName?.split(' ')[0] || '';
  const heading  = document.getElementById('welcome-heading');

  /* Personalise heading with first name when available */
  if (userName) {
    /* "What do you want to explore?" → "What do you want to explore, Alex?" */
    const base = screen.heading.replace(/[?!]$/, '');
    heading.textContent = `${base}, ${userName}?`;
  } else {
    heading.textContent = screen.heading;
  }
}

/* ================================================================
   9. IMAGE GENERATION (Pollinations.ai)
   ================================================================ */

/**
 * Detect if the user message is an image generation request
 */
function isImageRequest(text) {
  const lower = text.toLowerCase();
  const triggers = [
    'generate an image', 'generate image', 'create an image', 'create image',
    'draw', 'make an image', 'make image', 'paint', 'visualize', 'render an image',
    'image of', 'picture of', 'photo of', 'illustration of',
    '/image', '/img', '/draw',
  ];
  return triggers.some(t => lower.includes(t));
}

/**
 * Extract image prompt from a message like "generate an image of a sunset"
 */
function extractImagePrompt(text) {
  const lower = text.toLowerCase();
  const patterns = [
    /(?:generate|create|draw|make|render|paint|visualize)\s+(?:an?\s+)?(?:image|picture|photo|illustration|art)\s+(?:of\s+)?(.+)/i,
    /(?:image|picture|photo)\s+of\s+(.+)/i,
    /\/(?:image|img|draw)\s+(.+)/i,
  ];
  for (const p of patterns) {
    const match = text.match(p);
    if (match) return match[1].trim();
  }
  /* Fallback: use the whole message */
  return text;
}

/**
 * Handle an image generation request from the user
 */
async function handleImageGenRequest(userText) {
  const prompt = extractImagePrompt(userText);

  /* Show the user message */
  const userMsg = { role: 'user', content: userText, ts: Date.now() };
  state.messages.push(userMsg);
  hideWelcomeScreen();
  appendMessage(userMsg);
  scrollToBottom();

  /* Create new chat record if needed */
  if (!state.activeChatId && !state.isPrivateChat) {
    state.activeChatId = await saveNewChat(`Image: ${prompt.slice(0, 50)}`, state.messages);
  }

  /* Show loading */
  state.isLoading = true;
  setInputDisabled(true);
  showThinkingIndicator();

  try {
    const imageUrl = await generatePollinationsImage(prompt);
    const imageMsg = {
      role: 'assistant',
      content: `Here's your image for: **${prompt}**\n\n![Generated Image](${imageUrl})`,
      ts: Date.now(),
    };
    state.messages.push(imageMsg);
    appendMessage(imageMsg);
    await updateChatMessages(state.activeChatId, state.messages);
  } catch (err) {
    appendErrorMessage('Image generation failed: ' + err.message);
  } finally {
    state.isLoading = false;
    setInputDisabled(false);
    hideThinkingIndicator();
    scrollToBottom();
  }
}

/**
 * Generate an image using Pollinations.ai (free, no API key)
 * @param {string} prompt
 * @returns {Promise<string>} image URL
 */
async function generatePollinationsImage(prompt) {
  const encoded = encodeURIComponent(prompt);
  /* Add a seed for variety + nologo param */
  const seed = Math.floor(Math.random() * 1000000);
  const url  = `${POLLINATIONS_BASE}/${encoded}?seed=${seed}&width=1024&height=768&nologo=true&model=flux`;

  /* Verify the image loads */
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload  = () => resolve(url);
    img.onerror = () => reject(new Error('Image failed to load from Pollinations'));
    img.src = url;
    /* Timeout after 30s */
    setTimeout(() => reject(new Error('Image generation timed out')), 30000);
  });
}

/**
 * Open the image generation modal from the star button
 */
function openImageGenModal() {
  document.getElementById('modal-image-gen').classList.remove('hidden');
  document.getElementById('image-prompt-input').value = '';
  document.getElementById('image-prompt-input').focus();
}

/* ================================================================
   10. MEMORY AUTO-EXTRACTION
   ================================================================ */

/**
 * Patterns that suggest the user shared a personal fact
 * Nyx will remember these automatically.
 */
const MEMORY_PATTERNS = [
  /my name is ([A-Z][a-z]+(?: [A-Z][a-z]+)*)/i,
  /i(?:'m| am) ([a-zA-Z\s]+(?:developer|designer|engineer|student|researcher|writer|teacher))/i,
  /i(?:'m| am) (?:from|based in|living in) ([a-zA-Z\s,]+)/i,
  /i(?:'m| am) (\d+) years old/i,
  /i work (?:at|for) ([a-zA-Z\s]+)/i,
  /i(?:'m| am) (?:a|an) ([a-zA-Z\s]+)/i,
  /i use ([a-zA-Z\s]+) (?:for|as)/i,
  /my (?:favorite|preferred) (?:language|framework|tool) is ([a-zA-Z\s]+)/i,
  /i prefer ([a-zA-Z\s]+)/i,
];

/**
 * Scan the user message for memorable facts and store them.
 * Keeps the memory list lean (avoids duplicates).
 */
async function autoExtractMemories(userText, _assistantText) {
  for (const pattern of MEMORY_PATTERNS) {
    const match = userText.match(pattern);
    if (!match) continue;

    const fact = userText.slice(0, 120); // Store context around the fact
    const alreadyKnown = state.memories.some(m =>
      m.text.toLowerCase().includes(match[1].toLowerCase())
    );

    if (!alreadyKnown) {
      await addMemory(fact);
      showToast('Nyx remembered: ' + fact.slice(0, 60) + '…', 'info');
    }
  }
}

/* ================================================================
   11. SIDEBAR RENDERING
   ================================================================ */

/**
 * Render the full chat list in the sidebar
 */
function renderChatList() {
  const container = document.getElementById('chats-list');

  /* Keep the date-group labels and items */
  container.innerHTML = '';

  if (state.chats.length === 0) {
    container.innerHTML = '<p style="padding:8px 10px;font-size:12px;color:var(--text-muted)">No chats yet</p>';
    return;
  }

  /* Group chats by date */
  const groups = groupChatsByDate(state.chats);

  for (const [label, chats] of Object.entries(groups)) {
    /* Date label */
    const dateEl = document.createElement('div');
    dateEl.className = 'chats-date-label';
    dateEl.textContent = label;
    container.appendChild(dateEl);

    /* Chat items */
    for (const chat of chats) {
      const btn = document.createElement('button');
      btn.className = `sidebar-item${state.activeChatId === chat.id ? ' active' : ''}`;
      btn.dataset.chatId = chat.id;
      btn.textContent = chat.title || 'Untitled Chat';
      btn.title = chat.title || 'Untitled Chat';
      btn.addEventListener('click', () => openChat(chat.id));

      /* Right-click context menu for delete */
      btn.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        if (confirm(`Delete "${chat.title}"?`)) deleteChat(chat.id);
      });

      container.appendChild(btn);
    }
  }
}

/** Group chats into Today / Yesterday / This Week / Older */
function groupChatsByDate(chats) {
  const now       = new Date();
  const todayStr  = now.toDateString();
  const yday      = new Date(now); yday.setDate(yday.getDate() - 1);
  const ydayStr   = yday.toDateString();
  const weekAgo   = new Date(now); weekAgo.setDate(weekAgo.getDate() - 7);

  const groups = { Today: [], Yesterday: [], 'This Week': [], Older: [] };

  for (const chat of chats) {
    const d = chat.createdAt?.toDate?.() || new Date(chat.createdAt);
    const s = d.toDateString();
    if (s === todayStr)          groups.Today.push(chat);
    else if (s === ydayStr)      groups.Yesterday.push(chat);
    else if (d >= weekAgo)       groups['This Week'].push(chat);
    else                         groups.Older.push(chat);
  }

  /* Remove empty groups */
  return Object.fromEntries(Object.entries(groups).filter(([, v]) => v.length > 0));
}

/**
 * Render the projects list in the sidebar
 */
function renderProjectList() {
  const container = document.getElementById('projects-list');

  /* Keep the "New Project" button at the top */
  const newBtn = container.querySelector('#new-project-btn');

  /* Clear old project items (keep newBtn) */
  Array.from(container.children).forEach(child => {
    if (child.id !== 'new-project-btn') child.remove();
  });

  for (const project of state.projects) {
    const btn = document.createElement('button');
    btn.className = `sidebar-item${state.activeProjectId === project.id ? ' active' : ''}`;
    btn.dataset.projectId = project.id;

    const icon = { coding: '⚙️', writing: '✍️', research: '🔬', other: '📁' }[project.type] || '📁';
    btn.textContent = `${icon} ${project.name}`;
    btn.title = project.name;
    btn.addEventListener('click', () => openProject(project.id));
    container.appendChild(btn);
  }
}

/**
 * Filter the chat list by search query
 */
function filterChats(query) {
  const q = query.toLowerCase().trim();
  document.querySelectorAll('#chats-list .sidebar-item').forEach(el => {
    const matches = el.textContent.toLowerCase().includes(q);
    el.style.display = matches ? '' : 'none';
  });
}

/* ================================================================
   12. PROJECTS VIEW
   ================================================================ */

/**
 * Open a project (replaces the chat view with the project view)
 */
function openProject(projectId) {
  const project = state.projects.find(p => p.id === projectId);
  if (!project) return;

  state.activeProjectId = projectId;
  state.activeChatId    = null;

  /* Show project view, hide chat view */
  document.getElementById('main-content').style.display = 'none';
  const pv = document.getElementById('project-view');
  pv.classList.remove('hidden');

  /* Populate project data */
  document.getElementById('project-title').textContent = project.name;
  document.getElementById('project-notes-input').value = project.notes || '';

  /* Highlight in sidebar */
  document.querySelectorAll('.sidebar-item').forEach(el => {
    el.classList.toggle('active', el.dataset.projectId === projectId);
  });
}

/** Go back from project view to the chat/welcome view */
function closeProjectView() {
  state.activeProjectId = null;
  document.getElementById('project-view').classList.add('hidden');
  document.getElementById('main-content').style.display = 'flex';
  openNewChat();
}

/* ================================================================
   13. UI HELPER FUNCTIONS
   ================================================================ */

/** Enable or disable ALL chat inputs + send buttons */
function setInputDisabled(disabled) {
  ['chat-input', 'chat-input-chat'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.disabled = disabled;
  });
  ['send-btn', 'send-btn-chat'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.disabled = disabled;
  });
}

/** Show the thinking/loading indicator */
function showThinkingIndicator() {
  document.getElementById('thinking-indicator').classList.remove('hidden');
}

/** Hide the thinking/loading indicator */
function hideThinkingIndicator() {
  document.getElementById('thinking-indicator').classList.add('hidden');
}

/** Toggle the sidebar open/closed */
function toggleSidebar() {
  state.sidebarOpen = !state.sidebarOpen;
  const sidebar   = document.getElementById('sidebar');
  const openBtn   = document.getElementById('sidebar-open-btn');
  sidebar.classList.toggle('collapsed', !state.sidebarOpen);
  openBtn.classList.toggle('hidden', state.sidebarOpen);
}

/** Show a brief toast notification */
function showToast(message, type = 'info') {
  /* Remove existing toasts */
  document.querySelectorAll('.toast').forEach(t => t.remove());

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.style.cssText = `
    position:fixed; bottom:24px; right:24px; z-index:9999;
    background:${type === 'error' ? 'var(--danger)' : 'var(--bg-elevated)'};
    color:${type === 'error' ? '#fff' : 'var(--text-primary)'};
    border:1px solid var(--border); border-radius:var(--radius-md);
    padding:10px 16px; font-size:13px; max-width:360px;
    box-shadow:0 8px 24px rgba(0,0,0,0.4);
    animation:fadeInUp 0.2s ease;
  `;
  toast.textContent = message;
  document.body.appendChild(toast);

  setTimeout(() => toast.remove(), 3500);
}

/** Auto-resize the textarea as the user types */
function autoResizeTextarea(el) {
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 180) + 'px';
}

/* ================================================================
   14. MEMORY MANAGER MODAL
   ================================================================ */

function openMemoryModal() {
  renderMemoryList();
  document.getElementById('modal-memory').classList.remove('hidden');
}

function renderMemoryList() {
  const container = document.getElementById('memory-list');
  container.innerHTML = '';

  if (state.memories.length === 0) {
    container.innerHTML = '<p style="color:var(--text-muted);font-size:13px">No memories saved yet.</p>';
    return;
  }

  state.memories.forEach(mem => {
    const item = document.createElement('div');
    item.className = 'memory-item';
    item.innerHTML = `
      <span class="memory-item-text">${escapeHtml(mem.text)}</span>
      <button class="memory-item-del" data-id="${mem.id}" title="Delete">✕</button>`;
    item.querySelector('.memory-item-del').addEventListener('click', async () => {
      await deleteMemory(mem.id);
      renderMemoryList();
    });
    container.appendChild(item);
  });
}

/* ================================================================
   15. MODEL SELECTOR
   ================================================================ */

/**
 * Toggle the model dropdown visibility
 */
function toggleModelDropdown() {
  const dropdown = document.getElementById('model-dropdown');
  dropdown.classList.toggle('hidden');

  /* Close when clicking outside */
  if (!dropdown.classList.contains('hidden')) {
    setTimeout(() => {
      document.addEventListener('click', closeModelDropdown, { once: true });
    }, 0);
  }
}

function closeModelDropdown() {
  document.getElementById('model-dropdown').classList.add('hidden');
}

/**
 * Select a model
 */
function selectModel(modelId, label) {
  state.selectedModel = modelId;

  const shortLabel = label.split(' ').slice(0, 3).join(' ');
  const isfast     = modelId.includes('instant') || modelId.includes('8b') || modelId.includes('mini');
  const speedWord  = isfast ? 'Fast' : shortLabel.split(' ')[0];

  /* Update topbar label */
  document.getElementById('model-selector-label').textContent = shortLabel;

  /* Update ALL speed tags (welcome bar + chat bar) */
  ['input-speed-label', 'input-speed-label-chat'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.textContent = speedWord;
  });

  /* Mark selected option */
  document.querySelectorAll('.model-option').forEach(el => {
    el.classList.toggle('selected', el.dataset.model === modelId);
  });

  localStorage.setItem('nyx_model',       modelId);
  localStorage.setItem('nyx_model_label', label);

  closeModelDropdown();
}

/** Restore model selection from localStorage */
function restoreModelSelection() {
  const savedModel = localStorage.getItem('nyx_model');
  const savedLabel = localStorage.getItem('nyx_model_label');
  if (savedModel && savedLabel) {
    selectModel(savedModel, savedLabel);
  } else {
    /* Apply the default so topbar label and speed tag are correct on first load */
    selectModel(DEFAULT_MODEL, 'Llama 3.3 70B');
  }
}

/* ================================================================
   16. EVENT LISTENERS (wired up on DOMContentLoaded)
   ================================================================ */

document.addEventListener('DOMContentLoaded', () => {

 // Auth events
document.getElementById('btn-login').addEventListener('click', handleLogin);
document.getElementById('btn-signup').addEventListener('click', handleSignup);
document.getElementById('sign-out-btn').addEventListener('click', signOut);

// Allow Enter key on login inputs
['auth-id-input', 'auth-pass-input'].forEach(id => {
    document.getElementById(id)?.addEventListener('keydown', e => {
        if (e.key === 'Enter') handleLogin();
    });
});

// Allow Enter key on signup inputs
['auth-signup-id', 'auth-signup-name', 'auth-signup-pass', 'auth-signup-confirm'].forEach(id => {
    document.getElementById(id)?.addEventListener('keydown', e => {
        if (e.key === 'Enter') handleSignup();
    });
});

  /* ── Sidebar controls ──────────────────────────────────── */
  document.getElementById('sidebar-toggle')
    .addEventListener('click', toggleSidebar);
  document.getElementById('sidebar-open-btn')
    .addEventListener('click', toggleSidebar);

  /* New chat */
  document.getElementById('new-chat-btn')
    .addEventListener('click', () => openNewChat(false));

  /* Private / temp chat */
  document.getElementById('new-temp-chat-btn')
    .addEventListener('click', () => openNewChat(true));

  /* Search */
  document.getElementById('search-btn').addEventListener('click', () => {
    const box = document.getElementById('search-box');
    box.classList.toggle('hidden');
    if (!box.classList.contains('hidden')) {
      document.getElementById('search-input').focus();
    }
  });

  document.getElementById('search-input').addEventListener('input', (e) => {
    filterChats(e.target.value);
  });

  /* Projects section toggle */
  document.getElementById('projects-toggle').addEventListener('click', (e) => {
    const body = document.getElementById('projects-list');
    const btn  = e.currentTarget;
    body.classList.toggle('collapsed');
    btn.classList.toggle('open');
  });

  /* Chats section toggle */
  document.getElementById('chats-toggle').addEventListener('click', (e) => {
    const body = document.getElementById('chats-list');
    const btn  = e.currentTarget;
    body.classList.toggle('collapsed');
    btn.classList.toggle('open');
  });

  /* New project button */
  document.getElementById('new-project-btn').addEventListener('click', () => {
    document.getElementById('modal-new-project').classList.remove('hidden');
    document.getElementById('new-project-name').value = '';
    document.getElementById('new-project-name').focus();
  });

  /* ── User Profile ──────────────────────────────────────── */
  document.getElementById('user-profile-btn').addEventListener('click', (e) => {
    e.stopPropagation();
    document.getElementById('profile-dropdown').classList.toggle('hidden');
  });

  document.addEventListener('click', () => {
    document.getElementById('profile-dropdown').classList.add('hidden');
  });

  document.getElementById('sign-out-btn').addEventListener('click', signOut);

  document.getElementById('manage-memory-btn').addEventListener('click', () => {
    document.getElementById('profile-dropdown').classList.add('hidden');
    openMemoryModal();
  });

  /* ── Model Selector ────────────────────────────────────── */
  document.getElementById('model-selector-btn')
    .addEventListener('click', (e) => { e.stopPropagation(); toggleModelDropdown(); });

  /* Note: speed-tag btn-2 and btn-3 are wired inside wireInputBar() below */

  document.querySelectorAll('.model-option').forEach(btn => {
    btn.addEventListener('click', () => {
      selectModel(btn.dataset.model, btn.dataset.label);
    });
  });

  restoreModelSelection();

  /* ── Chat Input ────────────────────────────────────────── */
  /* ── Chat Input — wire BOTH input bars ──────────────────── */

  /* Helper: wire one textarea + send btn + attach btn combo */
  function wireInputBar(textareaId, sendBtnId, attachBtnId, imageGenBtnId, speedBtnId) {
    const el = document.getElementById(textareaId);
    if (!el) return;

    /* Auto-resize on typing */
    el.addEventListener('input', () => autoResizeTextarea(el));

    /* Enter = send, Shift+Enter = newline */
    el.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSend(textareaId);
      }
    });

    /* Send button */
    const sendBtn = document.getElementById(sendBtnId);
    if (sendBtn) sendBtn.addEventListener('click', () => handleSend(textareaId));

    /* Attach button → trigger hidden file input */
    const attachBtn = document.getElementById(attachBtnId);
    if (attachBtn) attachBtn.addEventListener('click', () => {
      document.getElementById('file-input').click();
    });

    /* Image gen button */
    const imgBtn = document.getElementById(imageGenBtnId);
    if (imgBtn) imgBtn.addEventListener('click', openImageGenModal);

    /* Speed/model tag */
    const speedBtn = document.getElementById(speedBtnId);
    if (speedBtn) speedBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleModelDropdown();
    });
  }

  /* Welcome-screen input bar */
  wireInputBar('chat-input', 'send-btn', 'attach-btn', 'image-gen-btn', 'model-selector-btn-2');

  /* Active-chat bottom input bar */
  wireInputBar('chat-input-chat', 'send-btn-chat', 'attach-btn-chat', 'image-gen-btn-chat', 'model-selector-btn-3');

  /* Single hidden file input (shared by both bars) */
  document.getElementById('file-input').addEventListener('change', handleFileSelect);

  /* ── Modals ────────────────────────────────────────────── */

  /* New Project modal */
  document.getElementById('cancel-new-project').addEventListener('click', () => {
    document.getElementById('modal-new-project').classList.add('hidden');
  });

  document.getElementById('confirm-new-project').addEventListener('click', async () => {
    const name = document.getElementById('new-project-name').value.trim();
    const type = document.getElementById('new-project-type').value;
    if (!name) return;
    document.getElementById('modal-new-project').classList.add('hidden');
    const id = await createProject(name, type);
    openProject(id);
  });

  /* New project on Enter key */
  document.getElementById('new-project-name').addEventListener('keydown', async (e) => {
    if (e.key === 'Enter') {
      document.getElementById('confirm-new-project').click();
    }
  });

  /* Memory modal */
  document.getElementById('close-memory-modal').addEventListener('click', () => {
    document.getElementById('modal-memory').classList.add('hidden');
  });

  document.getElementById('clear-all-memories').addEventListener('click', async () => {
    if (!confirm('Clear all memories? This cannot be undone.')) return;
    await clearAllMemories();
    renderMemoryList();
    showToast('All memories cleared');
  });

  /* Image gen modal */
  document.getElementById('cancel-image-gen').addEventListener('click', () => {
    document.getElementById('modal-image-gen').classList.add('hidden');
  });

  document.getElementById('confirm-image-gen').addEventListener('click', async () => {
    const prompt = document.getElementById('image-prompt-input').value.trim();
    if (!prompt) return;
    document.getElementById('modal-image-gen').classList.add('hidden');
    await handleImageGenRequest(`Generate an image of ${prompt}`);
  });

  /* Close modals on backdrop click */
  document.querySelectorAll('.modal').forEach(modal => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.classList.add('hidden');
    });
  });

  /* ── Project View ────────────────────────────────────────── */
  document.getElementById('back-from-project').addEventListener('click', closeProjectView);

  document.getElementById('delete-project-btn').addEventListener('click', async () => {
    const id = state.activeProjectId;
    if (!id || !confirm('Delete this project?')) return;
    await deleteProject(id);
    closeProjectView();
  });

  document.getElementById('save-project-notes').addEventListener('click', async () => {
    const notes = document.getElementById('project-notes-input').value;
    await updateProjectNotes(state.activeProjectId, notes);
    showToast('Notes saved');
  });

  /* Project tabs */
  document.querySelectorAll('.project-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.project-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      const tabName = tab.dataset.tab;
      document.getElementById('project-notes').classList.toggle('hidden', tabName !== 'notes');
      document.getElementById('project-files').classList.toggle('hidden', tabName !== 'files');
    });
  });

  /* ── PWA Service Worker ──────────────────────────────────── */
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker
      .register('../PWA-FILES/sw.js')
      .then(() => console.log('[Nyx] Service Worker registered'))
      .catch(err => console.warn('[Nyx] SW registration failed:', err));
  }

  /* ── Themes & Appearance panel ──────────────────────────── */

  /* Open themes modal from profile dropdown */
  document.getElementById('open-themes-btn').addEventListener('click', () => {
    document.getElementById('profile-dropdown').classList.add('hidden');
    document.getElementById('modal-themes').classList.remove('hidden');
    /* Reflect currently active theme on swatches */
    const current = document.documentElement.dataset.theme || 'dark';
    document.querySelectorAll('.theme-swatch').forEach(s => {
      s.classList.toggle('active', s.dataset.theme === current);
    });
  });

  /* Close themes modal */
  document.getElementById('close-themes-modal').addEventListener('click', () => {
    document.getElementById('modal-themes').classList.add('hidden');
  });

  /* Reset themes to defaults */
  document.getElementById('reset-themes-btn').addEventListener('click', () => {
    applyTheme('dark');
    applyFontSize(13.5);
    applySidebarWidth(260);
    document.getElementById('sidebar-width-range').value = 260;
    document.getElementById('sidebar-width-val').textContent = '260px';
    document.querySelectorAll('.font-size-btn').forEach(b =>
      b.classList.toggle('active', parseFloat(b.dataset.size) === 13.5)
    );
    localStorage.removeItem('nyx_theme');
    localStorage.removeItem('nyx_font_size');
    localStorage.removeItem('nyx_sidebar_w');
  });

  /* Theme swatch clicks */
  document.querySelectorAll('.theme-swatch').forEach(btn => {
    btn.addEventListener('click', () => {
      applyTheme(btn.dataset.theme);
      document.querySelectorAll('.theme-swatch').forEach(s => s.classList.remove('active'));
      btn.classList.add('active');
      localStorage.setItem('nyx_theme', btn.dataset.theme);
    });
  });

  /* Font size buttons */
  document.querySelectorAll('.font-size-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const size = parseFloat(btn.dataset.size);
      applyFontSize(size);
      document.querySelectorAll('.font-size-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      localStorage.setItem('nyx_font_size', size);
    });
  });

  /* Sidebar width slider */
  const widthRange = document.getElementById('sidebar-width-range');
  widthRange.addEventListener('input', () => {
    const w = parseInt(widthRange.value);
    document.getElementById('sidebar-width-val').textContent = w + 'px';
    applySidebarWidth(w);
  });
  widthRange.addEventListener('change', () => {
    localStorage.setItem('nyx_sidebar_w', widthRange.value);
  });

  /* Restore saved appearance preferences */
  restoreAppearance();

  /* ── Keyboard shortcuts ──────────────────────────────────── */
  document.addEventListener('keydown', (e) => {
    /* Cmd/Ctrl + K → focus chat input */
    if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
      e.preventDefault();
      /* Focus whichever input bar is currently visible */
      const welcomeVisible = !document.getElementById('welcome-screen').classList.contains('hidden');
      const targetId = welcomeVisible ? 'chat-input' : 'chat-input-chat';
      document.getElementById(targetId)?.focus();
    }
    /* Cmd/Ctrl + B → toggle sidebar */
    if ((e.metaKey || e.ctrlKey) && e.key === 'b') {
      e.preventDefault();
      toggleSidebar();
    }
    /* Escape → close any open modal or dropdown */
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal').forEach(m => m.classList.add('hidden'));
      closeModelDropdown();
      document.getElementById('profile-dropdown').classList.add('hidden');
    }
  });

});

/* ================================================================
   17. SEND HANDLER
   ================================================================ */

/**
 * Read the active textarea (welcome or chat bar), clear it, and send.
 * Accepts an optional element so both send buttons can call the same fn.
 */
function handleSend(sourceInputId) {
  /* If no specific source given, figure out which bar is visible */
  const id = sourceInputId ||
    (document.getElementById('welcome-screen').classList.contains('hidden')
      ? 'chat-input-chat'
      : 'chat-input');

  const inputEl = document.getElementById(id);
  if (!inputEl) return;
  const text = inputEl.value.trim();

  if (!text && state.attachedFiles.length === 0) return;

  /* Build message with any attached files */
  let finalText = text;
  if (state.attachedFiles.length > 0) {
    const fileParts = state.attachedFiles.map(f =>
      `\`\`\`${f.ext || 'text'} filename="${f.name}"\n${f.content}\n\`\`\``
    ).join('\n\n');
    finalText = text ? `${text}\n\n${fileParts}` : fileParts;
  }

  inputEl.value        = '';
  inputEl.style.height = 'auto';
  clearAttachedFiles();
  sendMessage(finalText);
}

/* ================================================================
   18. FILE ATTACHMENT HANDLING
   ================================================================ */

/** Attached files waiting to be sent: [ { name, ext, size, content } ] */
/* ================================================================
   18. FILE ATTACHMENT HANDLING
   ================================================================ */

/** Return a readable file size string e.g. "4.2 KB" */
function formatFileSize(bytes) {
  if (bytes < 1024)       return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

/**
 * Called when the user picks files via the hidden <input type="file">.
 * Reads each file as text and adds it to state.attachedFiles.
 */
async function handleFileSelect(event) {
  const files = Array.from(event.target.files);
  if (!files.length) return;

  for (const file of files) {
    /* Guard: skip files already attached (same name + size) */
    const duplicate = state.attachedFiles.some(
      f => f.name === file.name && f.size === file.size
    );
    if (duplicate) continue;

    /* Guard: 2 MB limit per file */
    if (file.size > 2 * 1024 * 1024) {
      showToast(`"${file.name}" is too large (max 2 MB)`, 'error');
      continue;
    }

    try {
      const content = await readFileAsText(file);
      const ext     = file.name.split('.').pop().toLowerCase();

      state.attachedFiles.push({
        name:    file.name,
        ext,
        size:    file.size,
        content,
      });

      addFileChip({ name: file.name, ext, size: file.size });

    } catch (err) {
      showToast(`Could not read "${file.name}": ${err.message}`, 'error');
    }
  }

  /* Reset the input so the same file can be picked again */
  event.target.value = '';
}

/**
 * Read a File object as UTF-8 text.
 * @returns {Promise<string>}
 */
function readFileAsText(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload  = () => resolve(reader.result);
    reader.onerror = () => reject(new Error('FileReader error'));
    reader.readAsText(file, 'UTF-8');
  });
}

/**
 * Render one chip in the file-chips strip for a newly attached file.
 * @param {{ name:string, ext:string, size:number }} fileInfo
 */
function addFileChip({ name, ext, size }) {
  const strip = document.getElementById('file-chips');
  strip.classList.remove('hidden');

  const icon = FILE_ICONS[ext] || '📄';

  const chip = document.createElement('div');
  chip.className        = 'file-chip';
  chip.dataset.fileName = name;
  chip.innerHTML = `
    <span class="file-chip-icon">${icon}</span>
    <span class="file-chip-name" title="${name}">${name}</span>
    <span class="file-chip-size">${formatFileSize(size)}</span>
    <button class="file-chip-remove" title="Remove file" aria-label="Remove ${name}">✕</button>
  `;

  /* Remove button removes from state + DOM */
  chip.querySelector('.file-chip-remove').addEventListener('click', () => {
    state.attachedFiles = state.attachedFiles.filter(f => f.name !== name);
    chip.remove();
    /* Hide strip when empty */
    if (document.querySelectorAll('.file-chip').length === 0) {
      strip.classList.add('hidden');
    }
  });

  strip.appendChild(chip);
}

/**
 * Clear all attached files and hide the chip strip.
 */
function clearAttachedFiles() {
  state.attachedFiles = [];
  const strip = document.getElementById('file-chips');
  strip.innerHTML = '';
  strip.classList.add('hidden');
}

/* ================================================================
   19. THEMES & APPEARANCE
   ================================================================ */

/**
 * Apply a named colour theme by setting data-theme on <html>.
 * The CSS file contains variable overrides for each theme name.
 */
function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
}

/**
 * Apply a base font size (px) to the root element.
 * Everything that uses em/rem scales automatically.
 */
function applyFontSize(size) {
  document.documentElement.style.fontSize = size + 'px';
}

/**
 * Dynamically update the --sb-w CSS variable and the sidebar element width,
 * so the slider preview is instant without a page reload.
 */
function applySidebarWidth(px) {
  document.documentElement.style.setProperty('--sb-w', px + 'px');
}

/**
 * Restore all saved appearance preferences from localStorage on load.
 */
function restoreAppearance() {
  const theme   = localStorage.getItem('nyx_theme');
  const fontSize = localStorage.getItem('nyx_font_size');
  const sbWidth  = localStorage.getItem('nyx_sidebar_w');

  if (theme)    applyTheme(theme);
  if (fontSize) {
    applyFontSize(parseFloat(fontSize));
    /* Highlight the matching font-size button */
    document.querySelectorAll('.font-size-btn').forEach(b => {
      b.classList.toggle('active', parseFloat(b.dataset.size) === parseFloat(fontSize));
    });
  }
  if (sbWidth) {
    const w = parseInt(sbWidth);
    applySidebarWidth(w);
    const range = document.getElementById('sidebar-width-range');
    const label = document.getElementById('sidebar-width-val');
    if (range) range.value = w;
    if (label) label.textContent = w + 'px';
  }
}
